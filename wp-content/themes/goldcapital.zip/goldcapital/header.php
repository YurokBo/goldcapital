<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta id="vp" name="viewport" content="width=device-width, initial-scale=1">
    <title>"<?php bloginfo( 'description' ); ?></title>
    <meta name="description" content="GoldCapital">
    <meta name="keywords" content="legals, accounting, business">
    <meta name="google-site-verification" content="uRzsov0ESwF23AdyriQ_eBfYtsm8IizkANhb913bXtM"/>
    <meta name="yandex-verification" content="0494a74b68568cd8"/>
    <!-- Favicon -->
    <!-- <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon"> -->
    <!-- OG Tags -->
    <meta property="og:title" content="GoldCapital">
    <meta property="og:description"
          content="Инвестиции в драгоценные металлы. Сезонный проект на росте золота, от 500% чистой прибыли">
    <meta property="og:type" content="GoldCapital">
    <meta property="og:image" content="img/phone.jpg">
    <meta property="og:site_name" content="GoldCapital">
    <!-- Bootstrap CSS -->

    <!-- Main CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;600;700;800&display=swap"
          rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">

    <?php wp_head(); ?>
</head>
<body>
<!-- Header -->
<header class="header" id="header">
    <div class="navigation">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-xl-2 col-lg-2 col-6">
                    <a href="#header" class="header-logo">
                        <!-- <img src="<?php bloginfo( 'template_url' ); ?>/assets/img/header-logo.png" alt="GoldCapital" class="header-logo__img img"> -->
                          <?php the_field('header-logo'); ?>
                    </a>
                </div>
                <div class="d-none col-xl-8 col-lg-7 d-lg-block ">
                    <ul class="menu d-flex justify-content-around">
                        <li class="menu__item">
                            <a href="#about" class="menu__link">
                                О компании
                            </a>
                        </li>
                        <li class="menu__item">
                            <a href="#services" class="menu__link">
                                Услуги
                            </a>
                        </li>
                        <li class="menu__item">
                            <a href="#creation" class="menu__link">
                                О проекте
                            </a>
                        </li>
                        <li class="menu__item">
                            <a href="#reviews" class="menu__link">
                                Отзывы
                            </a>
                        </li>
                        <li class="menu__item">
                            <a href="#contacts" class="menu__link">
                                Контакты
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-xl-2 col-lg-3 col-6 d-flex justify-content-end align-items-center">
                    <a href="https://alpari.com/ru/registration/?cpa_partner_id=12555567" target="_blank"
                       rel="nofollow noopener noreferrer" class="nav-btn btn ">
                        Регистрация
                    </a>
                    <button type="button" class="gamburger d-lg-none">
                        <span></span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div class="offer">
        <ul class="networks">
            <li class="networks__call">
                <a href=".consultation" target="_blank" class="networks__link networks__link_call"
                   rel="nofollow noopener noreferrer">
                    Заказать звонок
                </a>
            </li>
            <li class="networks__item networks__item_telegram">
                <div href=".hover" target="_blank" class="networks__link networks__links_telegram"
                     rel="nofollow noopener noreferrer">
                    <i class="fab fa-telegram-plane"></i>
                </div>
                <div class="hover">
                    <div class="hover__block">
                        <div class="hover__icon">
                            <i class="fab fa-telegram-plane"></i>
                        </div>
                    </div>
                    <a href="https://t.me/GoldCapital_official" target="_blank" class="hover__link"
                       rel="nofollow noopener noreferrer">
                        Основной
                    </a>
                    <a href="https://t.me/joinchat/GJ5DAkYiCFXyQ0FBNqLVgQ" target="_blank" class="hover__link"
                       rel="nofollow noopener noreferrer">
                        Чат
                    </a>
                </div>
            </li>
            <li class="networks__item">
                <a href="https://instagram.com/goldcapital_official" target="_blank" class="networks__link"
                   rel="nofollow noopener noreferrer">
                    <i class="fab fa-instagram"></i>
                </a>
            </li>
        </ul>
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="offer-slider">
                        <div class="offer-slider__item d-flex">
                            <div class="offer-slider__info">
                                <h1 class="offer-slider__title">
                                    Мы заработали «Большой куш»
                                </h1>
                                <p class="offer-slider__text">
                                    +1217% с декабря 2019 года по февраль 2020 год
                                </p>
                                <a href=".jackpot" class="btn">
                                    Узнать подробнее
                                </a>
                            </div>
                            <img src="<?php bloginfo( 'template_url' ); ?>/assets/img/phone.jpg" alt="phone" class="offer-slider__img img">
                        </div>
                        <div class="offer-slider__item d-flex">
                            <div class="offer-slider__info">
                                <h1 class="offer-slider__title">
                                    А что говорят наши клиенты?
                                </h1>
                                <a href="#reviews" class="btn">
                                    Читать отзывы
                                </a>
                            </div>
                            <img src="<?php bloginfo( 'template_url' ); ?>/assets/img/man.jpg" alt="man" class="offer-slider__img img">
                        </div>
                        <div class="offer-slider__item d-flex">
                            <div class="offer-slider__info">
                                <h1 class="offer-slider__title">
                                    Любой может зарабатывать больше
                                </h1>
                                <p class="offer-slider__text">
                                    Моя история тому доказательство
                                </p>
                                <a href=".director" class="btn">
                                    Читать подробнее
                                </a>
                            </div>
                            <img src="<?php bloginfo( 'template_url' ); ?>/assets/img/gold.jpg" alt="gold" class="offer-slider__img img">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <ul class="offer-list d-flex justify-content-between">
                        <li class="offer-list__item">
                            <p class="offer-list__text">
                                <span>5 лет</span>
                                работы над сезонным проектом
                            </p>
                        </li>
                        <li class="offer-list__item">
                            <p class="offer-list__text">
                                <span>+1217,5%</span>
                                рекордные показатели по прибыли
                            </p>
                        </li>
                        <li class="offer-list__item">
                            <p class="offer-list__text">
                                <span>35</span>
                                и более способов ввода и вывода средств
                            </p>
                        </li>
                        <li class="offer-list__item">
                            <p class="offer-list__text">
                                <span>24/7</span>
                                персональный финансовый консультант
                            </p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>
